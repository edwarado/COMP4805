# COMP4805

## Bitcoin Price Modelling via Text Analysis 

*******

### Useage

Open the index.html

In the data foler, The bitcoin price, bitcoin news, jupyter file and RStudio file could be found.
